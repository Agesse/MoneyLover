Money Lover
=====================

Keep an eye on your money.

## Using this project

Install the latest Ionic CLI:

```bash
$ npm install -g ionic
```

Then run:

```bash
$ ionic serve
```
