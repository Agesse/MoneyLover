Liste des specifications de l'application
=========================================

TODO
----

* Page de budget avec seuils et alertes
* Page de statistiques
* Ajout, suppression et edition d'entrees
* Ajout, suppression et edition de categories
* Design
* Doc & commentaires
* Revue de code
* Prod


Vue mensuelle
-------------

### Affichage

* Affichage du resume des depenses et des entrees (entrees - depenses = total)
* Affichage de la date quand differente de celle au dessus d'elle
* Affichage de l'icone de la categorie
* Affichage du libelle de la depense / entree
* Affichage du montant et differenciation des entrees et sorties
* Affichage special quand aucune information

### Interactions

* SWIPE pour changer le mois
* CLIC sur les fleches autour du mois pour changer le mois
* CLIC sur le nom du mois pour remettre a la date du jour
