import { Component } from '@angular/core';

@Component({
  selector: 'stats',
  templateUrl: 'stats.html'
})
export class StatsPage {

  constructor() {

  }

}
