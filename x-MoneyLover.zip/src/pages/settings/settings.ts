import { Component } from '@angular/core';

@Component({
  selector: 'settings',
  templateUrl: 'settings.html'
})
export class SettingsPage {

  constructor() {

  }

}
