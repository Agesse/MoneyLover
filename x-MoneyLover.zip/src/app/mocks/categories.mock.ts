export const MOCK_C = [
  {
    id: 0,
    cssSelector: "home",
    color: "blue",
    name: "Loyer",
    maxBudget: 600
  },
  {
    id: 1,
    cssSelector: "cash",
    color: "green",
    name: "Salaire",
    maxBudget: 1400
  },
  {
    id: 2,
    cssSelector: "game-controller-b",
    color: "yellow",
    name: "Loisirs",
    maxBudget: 1400
  }
]
