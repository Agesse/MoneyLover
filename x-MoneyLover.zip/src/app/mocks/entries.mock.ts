export const MOCK = [
  {
    "id": 123,
    "date": "10/12/2017",
    "category": 2,
    "libelle": "Lego",
    "value": 502.35,
    "income": false
  },
  {
    "id": 456,
    "date": "10/15/2017",
    "category": 0,
    "libelle": "Loyer",
    "value": 45.2,
    "income": false
  },
  {
    "id": 789,
    "date": "10/5/2017",
    "category": 1,
    "libelle": "Salaire",
    "value": 1045.2,
    "income": true
  },
  {
    "id": 987,
    "date": "10/21/2017",
    "category": 0,
    "libelle": "Assurance",
    "value": 54,
    "income": false
  },
  {
    "id": 45,
    "date": "10/15/2017",
    "category": 0,
    "libelle": "Assurances",
    "value": 25,
    "income": true
  },
  {
    "id": 46,
    "date": "09/15/2017",
    "category": 1,
    "libelle": "Assurances",
    "value": 25,
    "income": true
  }
]
