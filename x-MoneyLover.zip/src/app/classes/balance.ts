export class Balance {
  income: number;
  outcome: number;
  remainder: number;
}
