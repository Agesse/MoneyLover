export class Category {
  id: number;
  cssSelector: string;
  name: string;
  color: string;
  maxBudget: number;
}
