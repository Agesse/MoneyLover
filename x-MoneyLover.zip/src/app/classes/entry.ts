export class Entry {
  id: number;
  date: Date;
  category: number;
  libelle: string;
  value: number;
  income: boolean;
}
