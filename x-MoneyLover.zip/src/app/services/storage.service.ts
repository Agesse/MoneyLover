import { Injectable } from "@angular/core";

import { Storage } from "@ionic/storage";
import { ToastController } from 'ionic-angular';

import { Entry } from "../classes/entry";
import { MOCK } from "../mocks/entries.mock";

@Injectable()
export class StorageService {

  constructor(public storage: Storage, public toastCtrl: ToastController) {
  }

  /**
   * @desc GET : id => entry
   * @param {number} id
   * @returns {Promise<Entry>}
   */
  /*getEntry(id: number): Promise<Entry> {
    return this.storage.get("entry " + id).then(entryStored => {
      var entry = new Entry();
      entry.id = id;
      entry.category = entryStored.category;
      entry.date = entryStored.date;
      entry.income = entryStored.income;
      entry.libelle = entryStored.libelle;
      entry.value = entryStored.value;
      return entry;
    });
  }*/

  /**
   * @desc GET : => Entry[]
   * @returns {Promise<Entry>}
   */
  getAllEntries(entryDate: Date): Promise<Entry[]> {
    return this.storage.keys().then(keys => {
      var entryTab: Entry[] = [];
      for (var i = 0, l = keys.length; i < l; i++) {
        if (keys[i].includes("entry")) {
          if (true) { //TODO: check de la date
            this.storage.get(keys[i]).then(entry => {
              entryTab.push(entry);
            })
          }
        }
      }
      return entryTab;
    });
  }

  /**
   * @desc SET : Entry
   * @param {Entry} entry
   */
  setEntry(entry: Entry): Promise<void> {
    return this.getRandomID("entry").then(id => {
      entry.id = id;
      this.storage.set("entry-" + id, entry).then((setOK => {
        this.notify("Nouvelle entrée créée");
      }), (setKO => {
        this.notify("Erreur dans la création de la nouvelle entrée", true);
      }));
    });
  }

  /**
   * @desc UPDATE : id, cle, valeur => boolean
   * @param {number} id - ID de l'Entry a modifier
   * @param {string} key - Cle a modifier dans l'Entry
   * @param {string} value - Nouvelle valeur
   * @returns {Promise<boolean>} True si l'update est OK, false sinon.
   */
  /*updateEntry(id: number, key: string, value: string): Promise<void> {
    return this.storage.get("entry " + id).then(entry => {
      entry[key] = value;
      this.storage.set("entry " + id, entry).then(updateOK => {
        return true;
      }, (updateKO => {
        return false;
      }));
    });
  }*/

  /**
   * @desc DEL : id => boolean
   * @param {number} id
   * @returns {Promise<boolean>} True si l'update est OK, false sinon.
   */
  /*delEntry(id: number): Promise<boolean> {
    return this.storage.remove("entry " + id).then(delOK => {
      return true;
    }, delKO => {
      return false;
    });
  }*/

  /**
   * @desc Cree un id random pour une table.
   * @param {string} table - Nom de la table en BDD.
   * @returns {Promise<number>}
   */
  getRandomID(table: string): Promise<number> {
    return this.storage.keys().then(keys => {
      var rand: number = 0;
      while (keys.indexOf(table + "-" + rand) > -1) {
        rand = Math.floor(Math.random() * 10000);
      }
      return rand;
    });
  }

  /**
   * @desc Cree une notification avec un texte custom
   * @param {string} text - Texte a afficher
   * @param {boolean} error - Vrai si on affiche une erreur
   */
  notify(text: string, error?: boolean) {
    var config = {
      message: text,
      duration: 2000,
      position: "bottom",
      cssClass: ""
    };
    if (error) {
      config.cssClass = "alert-error";
    }
    const toast = this.toastCtrl.create(config);
    toast.present();
  }

}
